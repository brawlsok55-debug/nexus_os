package com.nexus.os.core

import android.content.Context
import android.content.SharedPreferences

/** Единое хранилище настроек NEXUS OS. Ключи ORB подготовлены для Этапа 2. */
class NexusPrefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var orbEnabled: Boolean
        get() = sp.getBoolean(K_ORB_ENABLED, false)
        set(v) = sp.edit().putBoolean(K_ORB_ENABLED, v).apply()

    var orbSizeDp: Int
        get() = sp.getInt(K_ORB_SIZE, 56)
        set(v) = sp.edit().putInt(K_ORB_SIZE, v.coerceIn(40, 96)).apply()

    /** 0.2f..1f */
    var orbOpacity: Float
        get() = sp.getFloat(K_ORB_OPACITY, 0.9f)
        set(v) = sp.edit().putFloat(K_ORB_OPACITY, v.coerceIn(0.2f, 1f)).apply()

    var orbX: Int
        get() = sp.getInt(K_ORB_X, 0)
        set(v) = sp.edit().putInt(K_ORB_X, v).apply()

    var orbY: Int
        get() = sp.getInt(K_ORB_Y, 400)
        set(v) = sp.edit().putInt(K_ORB_Y, v).apply()

    private companion object {
        const val FILE = "nexus_prefs"
        const val K_ORB_ENABLED = "orb_enabled"
        const val K_ORB_SIZE = "orb_size_dp"
        const val K_ORB_OPACITY = "orb_opacity"
        const val K_ORB_X = "orb_x"
        const val K_ORB_Y = "orb_y"
    }
}
