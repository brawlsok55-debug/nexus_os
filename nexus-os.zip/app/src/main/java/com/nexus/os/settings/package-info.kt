/** SETTINGS — настройки приложения. Пакет зарезервирован под структуру модулей. */
package com.nexus.os.settings
