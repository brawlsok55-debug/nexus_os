package com.nexus.os

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.nexus.os.core.NexusModules
import com.nexus.os.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.versionText.text = getString(R.string.version_fmt, BuildConfigVersion.name(this))
        populateModules()
    }

    private fun populateModules() {
        val inflater = LayoutInflater.from(this)
        binding.moduleList.removeAllViews()
        NexusModules.all.forEach { module ->
            val item = inflater.inflate(R.layout.item_module, binding.moduleList, false)
            item.findViewById<TextView>(R.id.moduleName).setText(module.name)
            item.findViewById<TextView>(R.id.moduleDesc).setText(module.description)
            item.findViewById<TextView>(R.id.moduleStatus).apply {
                setText(module.status.label)
                setTextColor(ContextCompat.getColor(context, module.status.color))
            }
            binding.moduleList.addView(item)
        }
    }
}

private object BuildConfigVersion {
    fun name(a: AppCompatActivity): String =
        a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?"
}
