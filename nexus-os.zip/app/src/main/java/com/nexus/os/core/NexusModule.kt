package com.nexus.os.core

import androidx.annotation.ColorRes
import androidx.annotation.StringRes
import com.nexus.os.R

enum class ModuleStatus(@StringRes val label: Int, @ColorRes val color: Int) {
    READY(R.string.status_ready, R.color.nexus_status_ready),
    PLANNED(R.string.status_planned, R.color.nexus_status_planned)
}

data class NexusModule(
    @StringRes val name: Int,
    @StringRes val description: Int,
    val status: ModuleStatus
)

/** Реестр модулей. Статус обновляется по мере реализации этапов. */
object NexusModules {
    val all = listOf(
        NexusModule(R.string.mod_core, R.string.mod_core_desc, ModuleStatus.READY),
        NexusModule(R.string.mod_orb, R.string.mod_orb_desc, ModuleStatus.PLANNED),
        NexusModule(R.string.mod_menu, R.string.mod_menu_desc, ModuleStatus.PLANNED),
        NexusModule(R.string.mod_customizer, R.string.mod_customizer_desc, ModuleStatus.PLANNED),
        NexusModule(R.string.mod_assist, R.string.mod_assist_desc, ModuleStatus.PLANNED),
        NexusModule(R.string.mod_settings, R.string.mod_settings_desc, ModuleStatus.PLANNED)
    )
}
